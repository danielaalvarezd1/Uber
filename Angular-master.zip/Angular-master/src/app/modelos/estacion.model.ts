export class EstacionModelo{
    id?: String;
    nombre?: String;
    direccion?: string;
    coordenada_x?: string;
    coordenada_y?: string;
    tipo?: string;
  }