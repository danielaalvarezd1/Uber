export class RutaModelo{
    id?: String;
    tiempo_estimado?: number;
    origen?: string;
    destino?: string;
  }