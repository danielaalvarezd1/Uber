export class ServicioModelo{
    id?: String;
    fecha?: string;
    hora_inicio?: string;
    hora_fin?: string;
    placa_vehiculo?: string;
    nombre_conductor?: string;
    dinero_recogido?: string;
    ruta?: string;
  }
  