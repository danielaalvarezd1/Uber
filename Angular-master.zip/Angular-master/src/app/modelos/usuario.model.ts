export class UsuarioModelo{
    id?: String;
    nombre?: String;
    apellidos?: string;
    telefono?: string;
    correo?: string;
    token?: string;
    isLoggedIn?: boolean = false;
  }
  